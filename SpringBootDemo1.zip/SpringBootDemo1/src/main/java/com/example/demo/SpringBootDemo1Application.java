package com.example.demo;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringBootDemo1Application 
{
	public static void main(String[] args) 
	{
		ApplicationContext ac=SpringApplication.run(SpringBootDemo1Application.class, args);
		Calculator c1=ac.getBean("calc",Calculator.class);
		c1.welcome();
		System.out.print("Enter 2 nos");
		Scanner ob=new Scanner(System.in);
		int a=ob.nextInt();
		int b=ob.nextInt();
		System.out.println("The sum of 2 nos is "+c1.sum(a, b));
		System.out.println("The sub of 2 nos is "+c1.sub(a, b));
		System.out.println("The mul of 2 nos is "+c1.mul(a, b));
		System.out.println("The div of 2 nos is "+c1.div(a, b));
		Employee e1=ac.getBean("emp",Employee.class);
	System.out.println("enter empno,name and address");
	int empno=ob.nextInt();
	String name=ob.next();
	String address=ob.next();
	e1.Display(empno,name,address);
	
	}
	
}
