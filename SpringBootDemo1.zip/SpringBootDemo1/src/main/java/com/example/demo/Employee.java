package com.example.demo;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee 
{
int empid;
String name,address;
public void Display(int empid, String name, String address) 
{
	this.empid = empid;
	this.name = name;
	this.address = address;
	System.out.println("the empid is "+empid);
	System.out.println("the emp name is "+name);
	System.out.println("the emp address is "+address);
	}

@Override
public String toString() {
	return "Employee [empid=" + empid + ", name=" + name + ", address=" + address + "]";
}

}
