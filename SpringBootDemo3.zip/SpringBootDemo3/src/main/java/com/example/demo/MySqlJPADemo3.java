package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class MySqlJPADemo3 implements CommandLineRunner,Ordered
{
@Autowired
private JdbcTemplate jt;
	@Override
	public void run(String... args) throws Exception {
		System.out.println("Third execution");
		String x="delete from student where rollno=?";
		int c=jt.update(x,102);
		System.out.println(c+" One row deleted");
	}
	@Override
	public int getOrder() {
				return 30;
	}

}
