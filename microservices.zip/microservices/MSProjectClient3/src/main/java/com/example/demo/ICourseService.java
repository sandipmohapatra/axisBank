package com.example.demo;

import java.util.List;

public interface ICourseService 
{
public Integer saveCourse(Course c);
public List<Course> getAllCourse();
public Course getOneCourse(Integer id);
}
