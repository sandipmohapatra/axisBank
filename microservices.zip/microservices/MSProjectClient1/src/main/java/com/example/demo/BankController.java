package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bank")
public class BankController 
{
@GetMapping("/details")
public String showMsg()
{
	String bankdetail="My Bank is SBI";
	System.out.println("Hello welcome to SBI");
	return bankdetail;
	
}
}
