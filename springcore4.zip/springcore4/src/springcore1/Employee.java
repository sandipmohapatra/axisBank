package springcore1;
import java.util.*;
public class Employee
{
private int empid;
private String name;
private List<String> projects;


public int getEmpid() {
	return empid;
}


public void setEmpid(int empid) {
	this.empid = empid;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public List<String> getProjects() {
	return projects;
}


public void setProjects(List<String> projects) {
	this.projects = projects;
}


public void display()
{
	System.out.println("the id is :"+empid);
	System.out.println("the name is :"+name);
	System.out.println("the project names are :");
		Iterator<String> itr=projects.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
}
}
